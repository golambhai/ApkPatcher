from ..ANSI_COLORS import ANSI; C = ANSI()


# ---------------- Credits ----------------
def Credits():
    exit(f"""
                     💢  Credit  💢

{C.S} Flutter SSL & TG Patch {C.E}{C.G} 🇮🇳 AbhiTheM0dder 🇮🇳 {C.S}{C.P} @AbhiTheM0dder {C.E}

{C.S} Pine Hook {C.E}{C.G} 🇮🇳 AbhiTheM0dder 🇮🇳 | 残页 {C.S}{C.P} @AbhiTheM0dder | @canyie {C.E}

{C.S} MITM {C.E}{C.G} Niklas Higi {C.S}{C.P} https://github.com/shroudedcode/apk-mitm {C.E}

{C.S} APKTool {C.E}{C.G} Connor Tumbleson {C.S}{C.P} @iBotPeaches {C.E}

{C.S} APKEditor {C.E}{C.G} REAndroid {C.S}{C.P} @kikfox {C.E}

{C.S} Uber-Apk-Signer {C.E}{C.G} Patrick Favre {C.S}{C.P} @patrickfav {C.E}

{C.S} My Channel {C.E}{C.CC} 🇮🇳 ࿗ {C.OG}T̴͢͢e̴͢͢c̴͢͢h̴͢͢n̴͢͢o̴͢͢ {C.B}☣{C.G} I̴͢͢n̴͢͢d̴͢͢i̴͢͢a̴͢͢ {C.CC}࿗ 🇮🇳 {C.S}{C.P} @rktechnoindians {C.E}

{C.S} CREATOR {C.E}{C.G} 𓄂 Ꭱꫝℑ 𓆐 ︻デ═一 ࿗ Я͓̽K͓̽ ࿗ {C.S}{C.P} @RK_TECHNO_INDIA {C.E}


{C.S}  NOTE  {C.E} {C.Y} Please Maintain Our Credits. 🙏🙏

    """)